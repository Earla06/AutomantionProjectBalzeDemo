package scriptfor_blazeDemo;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BazeDemo_HyperLink {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\saipr\\\\OneDrive\\\\Documents\\\\Automation Testing\\\\Browser Extension\\\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.get("https://blazedemo.com/");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[@href='vacation.html']")).click();
		Thread.sleep(2000);
		TakesScreenshot ss=(TakesScreenshot) driver;
		File src = ss.getScreenshotAs(OutputType.FILE);
		File des= new File("./ScreenShots/img2.jpg");
		FileUtils.copyFile(src,des);
		Thread.sleep(2000);
		driver.close();
		

	}

}
