98package scriptfor_blazeDemo;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDown_BlaxeDemo {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		Select s;

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\saipr\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.get("https://blazedemo.com/");
		Thread.sleep(2000);


		// Dropdown>> TagName must be <select> //Step 1: Create Object Of select class

		//Dropdown 1: 
		s= new Select(driver.findElement(By.xpath("//select[@name='fromPort']")));
		//step 2:select option 
		s.selectByValue("Portland");
		//s.selectByIndex(5);

		//Dropdown 2:
		/*
		 * s=new Select(driver.findElement(By.xpath("//select[@name='fromPort']")));
		 * 
		 * s.selectByIndex(5);
		 *  Thread.sleep(2000);
		 * 
		 * s.selectByIndex(0);
		 *  Thread.sleep(2000);
		 * 
		 * s.selectByIndex(3);
		 *  Thread.sleep(2000);
		 */

		s=new Select(driver.findElement(By.xpath("//select[@name='toPort']")));
		s.selectByIndex(4);

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("inputName")).sendKeys("Earla Saiprasanna");
		Thread.sleep(2000);
		driver.findElement(By.id("address")).sendKeys("E-126/B");
		Thread.sleep(2000);
		driver.findElement(By.id("city")).sendKeys("Karimnagar");
		Thread.sleep(2000);
		driver.findElement(By.id("state")).sendKeys("Telangana");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='12345']")).sendKeys("585222");
		Thread.sleep(2000);
		s=new Select(driver.findElement(By.id("cardType")));
		s.selectByIndex(1);
		Thread.sleep(2000);
		driver.findElement(By.id("creditCardNumber")).sendKeys("123456789");
		Thread.sleep(2000);
		driver.findElement(By.id("creditCardMonth")).sendKeys("12");
		Thread.sleep(2000);
		driver.findElement(By.id("creditCardYear")).sendKeys("2021");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='John Smith']")).sendKeys("saiprasanna");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input[type='checkbox']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@value='Purchase Flight']")).click();
		Thread.sleep(2000);
		TakesScreenshot ss=(TakesScreenshot) driver;
		File src = ss.getScreenshotAs(OutputType.FILE);
		File des= new File("./ScreenShots/img1.jpg");
		FileUtils.copyFile(src,des);
		driver.close();

	}

	
}


