package scriptfor_blazeDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BlazeDemo_HomeLogin {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\saipr\\\\OneDrive\\\\Documents\\\\Automation Testing\\\\Browser Extension\\\\chromedriver-win64\\\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.get("https://blazedemo.com/");
		Thread.sleep(2000);
		
		driver.findElement(By.linkText("home")).click();
		Thread.sleep(2000);

		driver.findElement(By.id("email")).sendKeys("prasannaachinni06@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("Prasu@123");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@type='checkbox']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		Thread.sleep(2000);
		
		driver.close();
		
		

	}

}
